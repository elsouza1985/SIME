<?php require_once 'config.php'; ?>
<?php include(HEADER_TEMPLATE) ?>

 <?php include(FOOTER_TEMPLATE);?>